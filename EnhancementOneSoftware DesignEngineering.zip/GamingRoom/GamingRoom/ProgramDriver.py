# package com.gamingroom;

"""
Application start-up program.

Original Author: coce@snhu.edu
Converted to Python by: [Your Name]
"""

from com.gamingroom import GameService, SingletonTester

class ProgramDriver:
    """
    The main driver class.
    """

    @staticmethod
    def main(args=None):
        # Get reference to the singleton instance
        service = GameService.get_instance()

        print("\nAbout to test initializing game data...")

        # Initialize with some game data
        game1 = service.add_game("Game #1")
        print(game1)

        game2 = service.add_game("Game #2")
        print(game2)

        # Use another class to prove there is only one instance
        tester = SingletonTester()
        tester.test_singleton()

if __name__ == '__main__':
    ProgramDriver.main()