"""
A simple class to hold information about a team.

Notice the constructor requires
an id and name to be passed when creating.
Also note that no mutators (setters) are defined, so
these values cannot be changed once a team is
created.

@author coce@snhu.edu (translated to Python)
"""


class Team:
    """
    Represents a team with an immutable id and name.
    """

    __slots__ = ("_id", "_name")  # Optional: Prevent dynamic attribute assignment for immutability and performance

    def __init__(self, id: int, name: str):
        """
        Initialize a new Team instance.

        :param id: Identifier for the team
        :param name: Name of the team
        """
        self._id = id
        self._name = name

    @property
    def id(self) -> int:
        """
        Returns the unique identifier for the team.
        """
        return self._id

    @property
    def name(self) -> str:
        """
        Returns the name of the team.
        """
        return self._name

    def __str__(self) -> str:
        """
        Returns a string representation of the Team.
        """
        return f"Team [id={self._id}, name={self._name}]"

    def __repr__(self) -> str:
        """
        Returns an unambiguous string representation of the object.
        """
        return f"Team(id={self._id!r}, name={self._name!r})"