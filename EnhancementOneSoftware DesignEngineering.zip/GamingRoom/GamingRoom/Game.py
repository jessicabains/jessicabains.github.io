"""
A simple class to hold information about a game.

Notice the constructor requires
an id and name to be passed when creating.
Also note that no mutators (setters) defined so
these values cannot be changed once a game is
created.

@author: Adapted from coce@snhu.edu (original Java version)
"""

class Game:
    """
    Game class models an immutable game with an id and name.
    """

    __slots__ = ['_id', '_name']

    def __init__(self, id: int, name: str):
        """
        Constructor with an identifier and name.

        :param id: Unique identifier for the game.
        :param name: Name of the game.
        """
        self._id = id
        self._name = name

    @property
    def id(self) -> int:
        """
        Returns the id.
        """
        return self._id

    @property
    def name(self) -> str:
        """
        Returns the name.
        """
        return self._name

    def __str__(self):
        return f"Game [id={self._id}, name={self._name}]"