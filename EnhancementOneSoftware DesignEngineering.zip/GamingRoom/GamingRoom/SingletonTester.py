# package com.gamingroom;

"""
A class to test a singleton's behavior.

Author: coce@snhu.edu
"""

from game_service import GameService  # Assumes GameService is defined in another module

class SingletonTester:
    """
    A class to test the singleton's behavior.
    """

    def test_singleton(self):
        print("\nAbout to test the singleton...")

        # Obtain local reference to the singleton instance
        service = GameService.get_instance()

        # Simple loop to print the games
        for i in range(service.get_game_count()):
            print(service.get_game(i))



if __name__ == "__main__":
    tester = SingletonTester()
    tester.test_singleton()

if __name__ == "__main__":
    tester = SingletonTester()
    tester.test_singleton()