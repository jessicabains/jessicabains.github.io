# package com.gamingroom;

"""
A simple class to hold information about a player.

Notice the constructor that requires an id and name to be passed when creating.
Also note that no mutators (setters) are defined so these values cannot be changed once
a player is created.

Author: coce@snhu.edu
"""

class Player:
    def __init__(self, id: int, name: str):
        """
        Constructor with an identifier and name.

        :param id: The player's unique identifier.
        :param name: The player's name.
        """
        self._id = id
        self._name = name

    @property
    def id(self) -> int:
        """Gets the id of the player."""
        return self._id

    @property
    def name(self) -> str:
        """Gets the name of the player."""
        return self._name

    def __str__(self):
        return f"Player [id={self._id}, name={self._name}]"