class GameService:
	"""
	A singleton service for the game engine.

	Author: coce@snhu.edu (converted to Python)
	"""

	from typing import Optional, List

	# Assuming a Game class exists in the same package/module structure.
	# You will need to implement or import the Game class accordingly.
	# Example placeholder (remove if you have your own Game implementation):
	class Game:
	    def __init__(self, game_id: int, name: str):
	        self._id = game_id
	        self._name = name

	    def get_id(self) -> int:
	        return self._id

	    def get_name(self) -> str:
	        return self._name

	class GameService:
	    """
	    A singleton service for the game engine.
	    """

	    _instance = None
	    _games: List[Game] = []
	    _next_game_id: int = 1

	    def __new__(cls):
	        """
	        Ensures only one instance of GameService exists (singleton pattern).
	        """
	        if cls._instance is None:
	            cls._instance = super(GameService, cls).__new__(cls)
	        return cls._instance

	    def add_game(self, name: str) -> Game:
	        """
	        Construct a new game instance.

	        :param name: the unique name of the game
	        :return: the game instance (new or existing)
	        """
	        for current_game in self._games:
	            if current_game.get_name() == name:
	                return current_game

	        game = Game(self._next_game_id, name)
	        self._next_game_id += 1
	        self._games.append(game)
	        return game

	    def _get_game_by_index(self, index: int) -> Game:
	        """
	        Returns the game instance at the specified index.
	        Scope is protected for testing purposes.
	        :param index: index position in the list to return
	        :return: requested game instance
	        """
	        return self._games[index]

	    def get_game(self, id_or_name) -> Optional[Game]:
	        """
	        Returns the game instance with the specified id or name.
	        Automatically detects by parameter type.

	        :param id_or_name: unique identifier or name of game to search for
	        :return: the requested game instance, or None if not found
	        """
	        if isinstance(id_or_name, int):
	            # Search by id
	            for current_game in self._games:
	                if current_game.get_id() == id_or_name:
	                    return current_game
	        elif isinstance(id_or_name, str):
	            # Search by name
	            for current_game in self._games:
	                if current_game.get_name() == id_or_name:
	                    return current_game
	        return None

	    def get_game_count(self) -> int:
	        """
	        Returns the number of games currently active.

	        :return: the number of games currently active
	        """
	        return len(self._games)

	# Usage (Singleton access pattern)
	# game_service = GameService()
	# OR always use: game_service = GameService()
	# This ensures only one instance exists.
