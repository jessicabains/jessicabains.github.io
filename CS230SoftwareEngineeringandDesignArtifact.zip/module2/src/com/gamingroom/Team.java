# package com.gamingroom;

1""" 
2A simple class to hold information about a team.
3
4Notice the constructor that requires an id and name to be passed when creating.
5Also note that properties are read-only so these values cannot be changed once a team is created.
6
7Author: coce@snhu.edu
8"""
9
10class Team:
11    def __init__(self, id: int, name: str):
12        """
13        Constructor with an identifier and name.
14        :param id: Unique identifier for the team.
15        :param name: Name of the team.
16        """
17        self._id = id
18        self._name = name
19
20    @property
21    def id(self) -> int:
22        """
23        Returns the team id.
24        :return: id
25        """
26        return self._id
27
28    @property
29    def name(self) -> str:
30        """
31        Returns the team name.
32        :return: name
33        """
34        return self._name
35
36    def __str__(self) -> str:
37        return f"Team [id={self._id}, name={self._name}]"
