#include <gtest/gtest.h>

TEST(ExampleSuite, BasicAssertion) {
    EXPECT_EQ(1 + 1, 2);
}

